# ClearReply — Website

A self-contained, responsive static website for ClearReply, ready for GitHub Pages.

## Files
- `index.html` — entire website, including CSS and JavaScript. No build process or external libraries required.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `clearreply`).
2. Upload `index.html` to the repository's root folder. You may also upload this README.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and the `/(root)` folder, then click **Save**.
6. Wait for GitHub Pages to publish and open the URL shown under the Pages settings.

## What the preview does
- Responsive ClearReply landing page and navigation.
- Interactive response selector with six options: agree, politely decline, request details, reply later, suggest a meeting, and keep in touch.
- Editable incoming-message, sender-name, sign-off, and suggested-reply fields.
- Copy-to-clipboard, regenerate, and reset controls.
- The sample replies are generated locally from templates. This website does not connect to Gmail, send email, or call a paid AI API.

## To connect a live AI service later
Add a backend endpoint and call it from the interactive demo. Do not put secret API keys into this static HTML or a public GitHub repository.

## Branding note
ClearReply is presented as an independent concept and is not affiliated with Google or Gmail.
